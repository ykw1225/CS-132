//Group member: eric chan, Kit Wong, koon yin
// Online Stroe Shopping System Version 1.0

/*LOG:
KIT: Just finished some simple menu and struct (4/5/17:42)
KIT: Finished add function
ERIC:finished remove function
KIT: finished little things in the product.cpp
KIT: fix a little thing, but reproNum function still not working
KIT: reproNum fuction fixed
KIT: added overload operator for product class and some additional constructors
ERIC: added static a member varable for counting total product have been created
*/

#include<iostream>
#include<string>
#include<iomanip>
#include"Product.h"
#include"ShoppingCart.h"
using namespace std;

void mainMenu(Product*&, int&, ShoppingCart&);
void customer(Product*&, ShoppingCart&);
void employee(Product*&, int&);
void add(Product*&, int&);
void isFull(Product*&, int&);
void reSize(Product*&, int&);
void remove(Product*&, int&);
void relocate(Product*&, int, int);
int indexOf(Product*, string);
void viewP(Product*&);
void inputCheck(int&, int, int);
void inputCheck(double&, double);

int main(){
        int dB_Size = 1; //Database size
        //int proNum = 0; //Currently product number
        Product* p = new Product[dB_Size]; //Product database
        ShoppingCart sc;
        mainMenu(p, dB_Size, sc);
        system("pause");
        delete []p;
        return 0;
}

// Home page menu
void mainMenu(Product*& p, int& dB_Size, ShoppingCart& sc){
    int select = 0;
    do{
                //cout << "***********************************\n";
                //p[0].display();
        cout << "***********************************\n"
             << "Welcome to EKK Online Store!\n"
             << "Main Menu:\n"
             << "\t1. Employee\n"
             << "\t2. Customer\n"
             << "\t0. Exit\n"
             << "Enter your selection(0~2): ";
                inputCheck(select, 0, 2);
                switch(select){
                        case 1: employee(p, dB_Size);
                                        break;
                        case 2: customer(p, sc);
                                        break;
                        case 0: break;
                }
        }while(select != 0);
}

// Menu for manage database
void employee(Product*& p, int& dB_Size){
    int select = 0;
    do{
                //cout << "***********************************\n";
                //p[0].display();
                cout << "***********************************\n"
                         << "* Currently have " << p->getTotalPro() << " products.\n"
                         << "* Product database still have " << dB_Size - p->getTotalPro() << " spaces!!!\n"
             << "Welcome Employee!\n"
             << "Management Menu:\n"
             << "\t1. Add Product\n"
             << "\t2. Remove Product\n"
             << "\t0. Back\n"
             << "Enter your selection(0~2): ";
                inputCheck(select, 0, 2);
                //cout << "select: " << select << endl;
                if(select == 1){
                        add(p, dB_Size);
                }
                else if(select == 2){
                        remove(p, dB_Size);
                }
    }while(select != 0);
}

// Adding a product into the database
void add(Product*& p, int& dB_Size){
    string name;
    double price;
        cout << "***********************************\n"
                 << "* Adding New Product" << endl;
    cout << "Enter name: ";
    getline(cin, name);
    cout << "Enter price: ";
    inputCheck(price, 0); //cout << "line 105" << endl;
	int index = p->getTotalPro();
    p[index] = Product(name, price); //cout << "line 106" << endl;//proNum++; 
	//cout << "line 107" << endl;
    //cout << "finished proNUm++" << endl;
    isFull(p, dB_Size);
}

// Check if the array if full, if it does, increase the proNum
void isFull(Product*& p, int& dB_Size){
        cout << "***********************************\n";
        cout << "* Size checked!!!" << endl;
    if(dB_Size == p->getTotalPro()){
                cout << "* Size is full!!!\n";
                reSize(p, dB_Size);
                //viewP(p, n);
        }
        else{
                cout << "* Size is not full!!!\n";
                //viewP(p, n);
        }
}

// Increase proNum of array if it's full
void reSize(Product*& p, int& dB_Size){
        cout << "***********************************\n";
        cout << "* Running resize function!!!\n";
        dB_Size *= 2;
    Product* temp = new Product[dB_Size];
   for(int i = 0; i < p->getTotalPro(); i++){
            //cout << "line 131" << endl;
                temp[i] = p[i];  //cout << "line 132" << endl;
    }
        delete []p;
    p = new Product[dB_Size];
        for(int i = 0; i < p->getTotalPro(); i++){
                p[i] = temp[i];
    }
        delete []temp;
        cout << "* Size increased!!!\n* New size: " << dB_Size << endl;
}

// Removing a product from database
void remove(Product*& p, int& dB_Size){
    string name;
        int j = 0;
        cout << "Enter product name to remove: ";
        getline(cin, name);
        cout << "***********************************\n";
        relocate(p, indexOf(p, name), dB_Size);
        //delete &p[p->getTotalPro()];
        //cout << "ending remove" << endl;
}

void relocate(Product*& p, int index, int dB_Size){
        if(index != dB_Size-1){
                // move the product to the end of the array
                while(index < dB_Size-1){
                        //cout << "second for loop" << endl;
                        p[index] = p[index + 1];
                        //cout << "* Relocated product #" << j+1 << endl;
                        index++;
                }
                p[index] = Product("", 0); 
                //re-initialize the product which need to remove
        }
        else p[index] = Product("", 0);;
}

int indexOf(Product* p, string name){
        for (int i = 0; i < p->getTotalPro(); i++){
                cout << "* Checking product #" << i+1 << endl;
                if (p[i].getName() == name){
                        cout << "* Matched product #" << i+1 << endl;
                        return i;
                }
        }
}

// Menu for shopping
void customer(Product*& p, ShoppingCart& sc){
    int select = 0;
    do{
                //cout << "***********************************\n";
                //p[0].display();
                cout << "***********************************\n"
             << "Welcom dear value customer!\n"
             << "Customer Menu:\n"
             << "\t1. View products\n"
             << "\t2. View shopping cart\n"
             << "\t3. Check out\n"
             << "\t0. Back\n"
             << "Enter your selection(0~3): ";
                inputCheck(select, 0, 3);
                switch(select){
                        case 1: viewP(p);
                                        break;
                        case 2: // calling the shoppingcart display function
                                        break;
                        case 3: // calling the shoppingcart display function and the total price and then ask billing and shipping information from user
                                        break;
                        case 0: break;
                }
    }while(select != 0);
}

// Viewing current products from database
void viewP(Product*& p){
        cout << "***********************************\n"
                 << "Products List" << endl;
        for (int i = 0; i < p->getTotalPro(); i++){
                cout << "\nProduct #" << i + 1 << ":\n";
                p[i].display();
        }
        cout << "* Press anykey to countinue!!!" << endl;
        system("pause");
}

// Check if user input is valid
void inputCheck(double& select, double min){
    cin >> select;
    while(select < min){
        cout << "* Invalid input, enter again: ";
        cin >> select;
    }
    cin.clear();
    cin.ignore(999, '\n');
}

void inputCheck(int& select, int min, int max){
    cin >> select;
    while(select < min || select > max){
        cout << "* Invalid input, enter again: ";
        cin >> select;
    }
    cin.clear();
    cin.ignore(999, '\n');
}
